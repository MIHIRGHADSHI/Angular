package com.learn.Ecommerce.repository;

public interface ProductRespository {

}
